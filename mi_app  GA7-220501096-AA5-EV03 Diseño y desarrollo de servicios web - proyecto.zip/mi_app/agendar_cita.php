<?php
session_start();
require 'config.php'; // Incluye la configuración de la base de datos

// Obtener la lista de médicos
$result_medicos = $conn->query("SELECT * FROM medicos");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $medico_id = $_POST['medico_id']; // ID del médico
    $fecha = $_POST['fecha']; // Fecha de la cita
    $hora = $_POST['hora']; // Hora de la cita

    // Obtener la especialidad y nombre del médico seleccionado
    $stmt_medico = $conn->prepare("SELECT nombre, especialidad FROM medicos WHERE id = ?");
    $stmt_medico->bind_param("i", $medico_id);
    $stmt_medico->execute();
    $stmt_medico->bind_result($medico_id, $especialidad);
    $stmt_medico->fetch();
    $stmt_medico->close();

    // Preparar la consulta SQL para insertar la cita
    $stmt = $conn->prepare("INSERT INTO citas (medico_id, fecha, hora, especialidad) VALUES (?, ?, ?, ?)");
    
    if ($stmt === false) {
        die("Error en la preparación de la consulta: " . $conn->error);
    }

    // Vincular parámetros
    if (!$stmt->bind_param("isss", $medico_id, $fecha, $hora, $especialidad)) {
        die("Error al vincular parámetros: " . $stmt->error);
    }

    // Ejecutar la consulta
    if (!$stmt->execute()) {
        die("Error al ejecutar la consulta: " . $stmt->error);
    }

    echo "Cita agendada exitosamente.";
    header("Location: lista_citas.php?message=" . urlencode("Cita agendada exitosamente.")); // Redirige con mensaje
    exit; // Asegúrate de usar exit después de header
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agendar Cita Médica</title>
    <link rel="stylesheet" href="agendar_cita.css"> <!-- Hoja de estilos -->
</head>
<body>
    <div class="form-logo-container"> <!-- Contenedor para el formulario y el logo -->
        <form method="POST" action="">
        <h2>Agendar Cita Médica</h2>
            <label for="medico_id">Selecciona un Médico:</label>
            <select name="medico_id" required>
                <?php while ($medico = $result_medicos->fetch_assoc()): ?>
                    <option value="<?php echo $medico['id']; ?>">
                        <?php echo $medico['nombre'] . " - " . $medico['especialidad']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <br>
            <label for="fecha">Fecha:</label>
            <input type="date" name="fecha" required>
            <br>
            <label for="hora">Hora:</label>
            <input type="time" name="hora" required>
            <br>
            <button type="submit">Agendar Cita</button>
            <p><a href="home.php">Volver a la página principal</a></p>
        </form>
        <div class="logo-container"> <!-- Contenedor para el logo -->
            <img src="img/LogoClinica.png" alt="Logo" class="logo"> 
        </div>
    </div>
</body>
</html>
