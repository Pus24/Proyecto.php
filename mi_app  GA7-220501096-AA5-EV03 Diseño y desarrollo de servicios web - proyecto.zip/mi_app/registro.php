<?php
session_start();
require 'config.php';
require 'funciones.php';

$message = ""; // Variable para el mensaje de registro

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $password_repeat = $_POST['password_repeat'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $direccion = $_POST['direccion'];

// Validar que las contraseñas coincidan
if ($password !== $password_repeat) {
    $message = "Las contraseñas no coinciden.";
} else {
    if (registrarUsuario($conn, $username, $password, $telefono, $correo, $direccion)) {
        $message = "Registro exitoso. Puedes iniciar sesión.";
        header("Location: login.php?message=" . urlencode($message)); // Redirige a la página de inicio de sesión con mensaje
        exit(); // Asegura que no se ejecute más código después de redirigir
    } else {
        $message = "Error en el registro: " . $conn->error;
    }
}
}
?>
<!DOCTYPE html>
<html lang="es">
<head>

   
<title>Clínica del Caribe</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; /* Fuente general para el cuerpo */
        }
        .titulo-container {
            background-color: white; /* Fondo blanco */
            padding: 20px; /* Espaciado interno */
            border-radius: 10px; /* Bordes redondeados */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Sombra para dar profundidad */
            text-align: center; /* Centrar texto en el div */
            margin: 20px; /* Margen alrededor del div */
        }
        .titulo {
            font-family: 'Georgia', serif; /* Fuente elegante */
            font-size: 3rem; /* Tamaño de la fuente */
            color: #007BFF; /* Color azul */
            text-transform: uppercase; /* Convierte a mayúsculas */
            letter-spacing: 2px; /* Espaciado entre letras */
            margin: 0; /* Eliminar margen para evitar espacios extra */
            display: inline-block; /* Hace que el h1 sea un bloque en línea */
            border-bottom: 3px solid #007BFF; /* Línea inferior */
            padding-bottom: 10px; /* Espaciado interno en la parte inferior */
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); /* Sombra de texto */
        }
    </style>
</head>
<body>
    <div class="titulo-container">
        <h1 class="titulo">Clínica del Caribe</h1>
    </div>


    <meta charset="UTF-8">
    <title>Registro</title>
    <link rel="stylesheet" href="registro.css"> <!-- Enlazar archivo CSS -->
</head>
<body>
    <div class="container">
        <div class="logo-container"> <!-- Contenedor para el logo -->
            <img src="img/LogoClinica.png" alt="Logo" class="logo"> 
        </div>
        <div class="form-container"> <!-- Contenedor para el formulario -->
            <h2>Registro de Usuario</h2>
            <?php if (!empty($message)): ?>
                <p><?php echo $message; ?></p> <!-- Muestra el mensaje si existe -->
            <?php endif; ?>
            <form method="POST" action="">
                <label>Nombre de usuario:</label>
                <input type="text" name="username" required>
                <br>
                <label>Contraseña:</label>
                <input type="password" name="password" required>
                <br>
                <label>Repetir Contraseña:</label>
                <input type="password" name="password_repeat" required>
                <br>
                <label>Teléfono:</label>
                <input type="tel" name="telefono" required>
                <br>
                <label>Correo:</label>
                <input type="email" name="correo" required>
                <br>
                <label>Dirección:</label>
                <input type="text" name="direccion" required>
                <br>
                <button type="submit">Registrarse</button>
                <br>
                
                <button type="button" onclick="alert('Esta es una función de captcha simulada.');" style="background-color: blue; color: white; padding: 10px 20px; border: none; border-radius: 5px; font-weight: bold; cursor: pointer;"> Captcha </button>
            </form>
            <p>¿Ya tienes una cuenta? <a href="login.php">Inicia sesión</a></p>
        </div>
        <div class="photo-container"> <!-- Contenedor para la foto y el texto -->
            <img src="img/Pacientes.jpg" alt="Foto" class="foto"> <!-- Foto -->
            <p class="welcome-text">¡Bienvenido a la Clínica del Caribe! Si deseas registrarte como paciente, completa el formulario y únete a nosotros, en la Clinica del Caribe seras bien atendido, tanto que no querras buscar mas opciones. </p> <!-- Texto de bienvenida -->
        </div>
    </div>   
</body>
</html>
