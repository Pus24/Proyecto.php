<?php
session_start();
require 'config.php'; // Incluye el archivo de configuración de la base de datos
require 'funciones.php'; // Incluye las funciones necesarias

// Verifica si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Obtener la lista de usuarios
$result = $conn->query("SELECT * FROM usuarios");

// Manejo de la eliminación de usuarios
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: lista_usuarios.php"); // Redirige después de eliminar
}

// Manejo de la edición de usuarios
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['editar'])) {
    $id = $_POST['id'];
    $username = $_POST['username'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $direccion = $_POST['direccion'];

    $stmt = $conn->prepare("UPDATE usuarios SET username = ?, telefono = ?, correo = ?, direccion = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $username, $telefono, $correo, $direccion, $id);
    $stmt->execute();
    header("Location: lista_usuarios.php"); // Redirige después de editar
}

// Manejo de mensaje de inicio de sesión
$message = "";
if (isset($_GET['message'])) {
    $message = $_GET['message']; // Obtiene el mensaje de la URL
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Usuarios</title>
    <link rel="stylesheet" href="lista_usuarios.css"> <!-- Enlazar archivo CSS -->
</head>
<body>
    <h2>Lista de Usuarios Registrados</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre de Usuario</th>
                <th>Teléfono</th>
                <th>Correo</th>
                <th>Dirección</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($usuario = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $usuario['id']; ?></td>
                    <td><?php echo $usuario['username']; ?></td>
                    <td><?php echo $usuario['telefono']; ?></td>
                    <td><?php echo $usuario['correo']; ?></td>
                    <td><?php echo $usuario['direccion']; ?></td>


                    <td>
                       <button class="editar" style="background-color: black; color: yellow;" data-id="<?php echo $usuario['id']; ?>">Editar</button>
                       <button class="eliminar" style="background-color: red; color: white;" 
                       onclick="if(confirm('¿Estás seguro de que deseas eliminar este usuario?')) window.location.href='?eliminar=<?php echo $usuario['id']; ?>';">Eliminar</button>
                    </td>
                <tr class="edit-form" id="edit-form-<?php echo $usuario['id']; ?>" style="display:none;">
                    <td colspan="6">
                        <form method="POST">
                            <input type="hidden" name="id" value="<?php echo $usuario['id']; ?>">
                            <input type="text" name="username" value="<?php echo $usuario['username']; ?>" required>
                            <input type="text" name="telefono" value="<?php echo $usuario['telefono']; ?>" required>
                            <input type="email" name="correo" value="<?php echo $usuario['correo']; ?>" required>
                            <input type="text" name="direccion" value="<?php echo $usuario['direccion']; ?>" required>
                            <button type="submit" name="editar" class="guardar">Guardar</button>
                            <button type="button" class="cancelar" data-id="<?php echo $usuario['id']; ?>">Cancelar</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <p>
    <a href="home.php" style="display: inline-block; background-color:green; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold;">Volver a la página principal</a>
    </p>

    <script>
        document.querySelectorAll('.editar').forEach(button => {
            button.addEventListener('click', function() {
                const id = this.dataset.id;
                document.getElementById(`edit-form-${id}`).style.display = 'table-row';
                this.closest('tr').style.display = 'none'; // Oculta la fila de datos
            });
        });

        document.querySelectorAll('.cancelar').forEach(button => {
            button.addEventListener('click', function() {
                const id = this.dataset.id;
                document.getElementById(`edit-form-${id}`).style.display = 'none'; // Oculta el formulario
                this.closest('tr').previousElementSibling.style.display = 'table-row'; // Muestra la fila de datos
            });
        });
    </script>
</body>
</html>
